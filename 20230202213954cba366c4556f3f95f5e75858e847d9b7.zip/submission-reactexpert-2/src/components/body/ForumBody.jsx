import React from 'react';
import { Route, Routes } from 'react-router-dom';
import { useSelector } from 'react-redux';
import AddPage from '../../pages/Layout/AddPage';
import DetailPage from '../../pages/Layout/DetailPage';
import HomePage from '../../pages/Layout/HomePage';
import LeaderboardPage from '../../pages/Layout/LeaderboardPage';
import LoginPage from '../../pages/PageAuth/LoginPage';
import RegisterPage from '../../pages/PageAuth/RegisterPage';
import NotFoundPage from '../../pages/PageNotFound/NotFoundPage';

const ForumBody = () => {
  const {
    authUser,
  } = useSelector((states) => states);

  if (authUser === null || authUser === undefined) {
    return (
      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/*" element={<NotFoundPage />} />
          <Route path="/threads/:id" element={<DetailPage />} />
          <Route path="/leaderboards" element={<LeaderboardPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
        </Routes>
      </main>
    );
  }

  return (
    <main>
      <Routes>
        <Route path="/" element={<HomePage authUser={authUser} />} />
        <Route path="/*" element={<NotFoundPage />} />
        <Route path="/threads/:id" element={<DetailPage />} />
        <Route path="/new" element={<AddPage />} />
        <Route path="/leaderboards" element={<LeaderboardPage />} />
        <Route path="/register" element={<RegisterPage />} />
      </Routes>
    </main>
  );
};

export default ForumBody;
