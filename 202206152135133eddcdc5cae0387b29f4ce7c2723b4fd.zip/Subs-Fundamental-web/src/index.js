import 'bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'popper.js/dist/popper.min.js';
import './style/style.css';
import "./script/component/nav-bar.js";
import "./script/component/search-bar.js";
import movies from "./script/data/main.js";
movies();