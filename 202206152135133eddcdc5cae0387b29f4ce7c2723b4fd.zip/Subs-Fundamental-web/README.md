Script

- `npm run start-dev` - to start locally
- `npm run build` - to build into folder dist
