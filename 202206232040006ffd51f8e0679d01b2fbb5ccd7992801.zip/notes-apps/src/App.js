import NoteApps from './pages/NoteApps';
import './assets/scss/style.scss';

function App() {
  return (
    <div className="App">
      <NoteApps />
    </div>
  );
}

export default App;
