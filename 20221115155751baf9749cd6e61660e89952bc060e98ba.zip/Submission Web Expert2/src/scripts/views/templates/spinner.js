const Spinner = () => `
  <div class="spinner-wrapper">
    <span class="spinner-grow merah" role="status"></span>
    <span class="spinner-grow kuning" role="status"></span>
    <span class="spinner-grow hijau" role="status"></span>
  </div>
`;

export default Spinner;
