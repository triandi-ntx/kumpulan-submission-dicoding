/* eslint-disable import/extensions */
/* eslint-disable import/no-unresolved */
import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
// eslint-disable-next-line import/extensions
import ThreadDetailHeader from '../../components/main/thread/ThreadDetailHeader';
// eslint-disable-next-line import/extensions
import ThreadDetailContent from '../../components/main/thread/ThreadDetailContent';
import ThreadDetailFooter from '../../components/main/thread/ThreadDetailFooter';
import ThreadDetailComment from '../../components/main/thread/ThreadDetailComment';
import { asyncReceiveThreadDetail, asyncAddComment } from '../../states/detailThread/action';

const DetailPage = () => {
  const { id } = useParams();
  const {
    threadDetail = null,
    authUser,
  } = useSelector((states) => states);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(asyncReceiveThreadDetail(id));
  }, [id, dispatch]);

  const onCreateComment = ({ content }) => {
    dispatch(asyncAddComment({ id, content }));
  };

  if (!threadDetail) {
    return null;
  }
  return (
    <section className="detail-page">
      <ThreadDetailHeader detail={threadDetail} />
      <ThreadDetailContent detail={threadDetail} />
      <ThreadDetailFooter detail={threadDetail} />
      <ThreadDetailComment
        onCreateComment={onCreateComment}
        authUser={authUser}
        detail={threadDetail}
      />
    </section>
  );
};
export default DetailPage;
