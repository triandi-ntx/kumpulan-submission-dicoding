export default function NoteDetailEmpty() {
  return (
    <div className="section">
      <div className="content">
        <h1>Note is Not Found</h1>
      </div>
    </div>
  );
}
