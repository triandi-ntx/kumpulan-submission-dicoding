function NotFoundPage() {
  return (
    <div className="section">
      <div className="content">
        <h1>Page Not Found</h1>
      </div>
    </div>
  );
}

export default NotFoundPage;
