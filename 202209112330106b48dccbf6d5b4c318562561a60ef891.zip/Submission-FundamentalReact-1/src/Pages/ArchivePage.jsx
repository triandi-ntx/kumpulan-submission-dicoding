import NoteListPageWrapper from './NoteListPage';

function ArchivePage() {
  return <NoteListPageWrapper isArchived={true} />;
}

export default ArchivePage;
