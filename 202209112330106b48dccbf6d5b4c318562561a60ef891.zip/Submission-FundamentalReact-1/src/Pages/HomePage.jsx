import NoteListPageWrapper from './NoteListPage';

function HomePage() {
  return <NoteListPageWrapper isArchived={false} />;
}

export default HomePage;
