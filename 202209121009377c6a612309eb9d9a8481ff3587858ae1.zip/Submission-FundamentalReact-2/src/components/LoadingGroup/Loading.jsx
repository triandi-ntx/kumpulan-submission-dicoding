function Loading() {
  return <p className="has-text-centered title">Loading ...</p>;
}

export default Loading;
