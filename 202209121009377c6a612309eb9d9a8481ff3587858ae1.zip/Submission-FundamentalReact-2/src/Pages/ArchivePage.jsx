import NoteListPageWrapper from './NoteListPage';

function ArchivePage() {
  return <NoteListPageWrapper isArchived />;
}

export default ArchivePage;
