import NoteListPageWrapper from './NoteListPage';

function HomePage() {
  return <NoteListPageWrapper />;
}

export default HomePage;
